-- MySQL dump 10.13  Distrib 8.0.34, for macos13 (arm64)
--
-- Host: 127.0.0.1    Database: dmu
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student` (
  `student_id` varchar(20) NOT NULL,
  `pw` varchar(255) NOT NULL,
  `name` varchar(50) NOT NULL,
  `grade` int NOT NULL,
  `department` varchar(100) NOT NULL,
  `status` enum('재학','휴학') NOT NULL,
  PRIMARY KEY (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES ('20202384','20202384','차성준',3,'인공지능소프트웨어학과','재학'),('20210001','pw1111','강은비',1,'생명화학공학과','재학'),('20210002','pw2222','윤지호',2,'건축과','재학'),('20210003','pw3333','백서현',1,'시각디자인과','휴학'),('20210004','pw4444','김동혁',1,'호텔관광학과','재학'),('20210005','pw5555','이채린',2,'소방안전관리과','재학'),('20210006','pw2223','양민지',1,'기계설계공학과','재학'),('20210007','pw2323','김재훈',1,'생명화학공학과','재학'),('20210008','pw2424','이유정',2,'웹응용소프트웨어공학과','재학'),('20210009','pw2525','박민혁',1,'경영학과','재학'),('20210010','pw2626','최은서',2,'바이오융합공학과','재학'),('20220001','pw6789','한지민',1,'웹응용소프트웨어공학과','재학'),('20220002','pw7890','서준혁',2,'세무회계학과','휴학'),('20220003','pw8901','이지우',2,'기계설계공학과','재학'),('20220004','pw9012','김다은',2,'정보통신공학과','재학'),('20220005','pw0123','오세훈',1,'자동화공학과','재학'),('20220006','pw1717','홍정우',1,'자유전공학과','재학'),('20220007','pw1818','김하은',1,'산업디자인과','재학'),('20220008','pw1919','박찬호',2,'경영정보학과','휴학'),('20220009','pw2020','이도현',1,'소방안전관리과','재학'),('20220010','pw2121','서지후',2,'전기공학과','재학'),('20220011','pw3737','이정훈',1,'소방안전관리과','재학'),('20220012','pw3838','최하늘',2,'AR·VR콘텐츠디자인과','재학'),('20220013','pw3939','강민석',2,'호텔관광학과','재학'),('20220014','pw4040','신예린',1,'시각디자인과','재학'),('20220015','pw4141','김지후',2,'기계설계공학과','재학'),('20230001','pw1234','김민수',3,'컴퓨터소프트웨어공학과','재학'),('20230002','pw2345','이서연',2,'인공지능소프트웨어학과','재학'),('20230003','pw3456','박지훈',2,'경영학과','휴학'),('20230004','pw4567','최유진',1,'기계공학과','재학'),('20230005','pw5678','정현우',2,'전기공학과','재학'),('20230006','pw1212','권유정',1,'경영학과','재학'),('20230007','pw1313','김세영',2,'세무회계학과','휴학'),('20230008','pw1414','이승민',1,'실내건축디자인과','재학'),('20230009','pw1515','장민서',1,'빅데이터경영과','재학'),('20230010','pw1616','조예은',2,'반도체전자공학과','재학'),('20230011','pw3232','윤소민',2,'기계공학과','재학'),('20230012','pw3334','서현우',3,'건축과','재학'),('20230013','pw3434','김은지',2,'유통마케팅학과','휴학'),('20230014','pw3535','박시우',1,'인공지능소프트웨어학과','재학'),('20230015','pw3636','정예원',2,'자동화공학과','재학'),('20231597','pw20231597','최지안',2,'인공지능소프트웨어학과','재학'),('20250001','pw6666','정민우',1,'경영정보학과','재학'),('20250002','pw7777','박하린',1,'유통마케팅학과','재학'),('20250003','pw8888','송예진',1,'AR·VR콘텐츠디자인과','재학'),('20250004','pw9999','조현서',1,'로봇소프트웨어과','재학'),('20250005','pw0000','임도윤',1,'바이오융합공학과','재학'),('20250006','pw2727','한승우',1,'컴퓨터소프트웨어공학과','재학'),('20250007','pw2828','문가영',1,'세무회계학과','재학'),('20250008','pw2929','류지호',1,'정보통신공학과','재학'),('20250009','pw3030','이예린',1,'시각디자인과','재학'),('20250010','pw3131','김도윤',1,'경영정보학과','재학');
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-04  1:42:36
